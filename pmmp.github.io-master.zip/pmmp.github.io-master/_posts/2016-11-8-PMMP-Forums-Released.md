---
layout: post
title: PMMP Forums Released
description: Official forums now open to the public.
image: assets/images/pmmpforum.jpg
author: 99leonchang
---

## Let's get discussing!

Today we are celebrating the official release of the [PMMP forums](https://forums.pmmp.io) for public consumption!

The new PMMP forums will provide a platform for non-bug related support as well as general discussion with the goal of fostering community relations (and reducing spam on the GitHub issues tracker).
It is a place for the community to interact with each other and the PMMP team, as well as get solutions to their problems.
The old PocketMine forums will still remain open for reference purposes, however, all new content pertaining PMMP should be posted in the new forums.

**[Jump over and make an account now](https://forums.pmmp.io)**!

We hope you like the forums and brand new features will be coming in the future.
